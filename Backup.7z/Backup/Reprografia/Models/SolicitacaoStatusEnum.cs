﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Reprografia.Models
{
    public enum SolicitacaoStatusEnum
    {
        Solicitada = 1,
        Entregue = 2,
        Avaliada = 3
    }
}
