﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Reprografia.BusinessLogic
{
    public enum StatusCriacaoSolicitacao
    {
        NaoAutenticacao,
        AvaliacaoPendente,
        NaoEspecificado,
        Permitido
    }
}
